//client
let socket;
function setup(){
  createCanvas(600, 400);
  background(51);
  socket = io.connect('apegolf.ddns.net:80'); //telling server you're connecting
  socket.on('mouse', newDrawing); //implied that its passing data. listening for mouse
}

function newDrawing(data){
  noStroke();
  fill(150);
  ellipse(data.x,data.y,36,36);
}

function mouseDragged(){
  console.log('Sending: ' + mouseX + ', ' + mouseY);
  var data = {
    x: mouseX, //data.x to access
    y: mouseY
  }
  socket.emit('mouse', data); //sending data to the server

  noStroke();
  fill(255);
  ellipse(mouseX,mouseY,36,36);
}

function draw(){

}
